#include <stdio.h>
#include "ads1115.h"

int main() {
    ADS1115_Config config = {
        .channel = ADS1115_AIN0_AIN1, // 初始通道设置（实际会被覆盖）
        .gain = ADS1115_PGA_2V048,    // ±2.048V量程
        .data_rate = ADS1115_DR_128SPS, // 128 samples/second
        .op_mode = ADS1115_MODE_SINGLE, // 单次转换模式
        .i2c_addr = ADS1115_DEFAULT_ADDR // 默认I2C地址0x48
    };

    // 打开设备（假设使用I2C总线1）
    int ret = ADS1115_Open(&config, 1);
    if (ret != ADS1115_OK) {
        printf("Failed to open ADS1115: %d\n", ret);
        return 1;
    }

    // 测量AIN1和AIN2之间的差分电压
    // 注意：ADS1115原生不支持AIN1-AIN2差分，需要外部连接
    // 如果需要单端测量AIN1或AIN2，请使用ADS1115_AIN1_GND或ADS1115_AIN2_GND
    float voltage;
    ret = ADS1115_ReadVoltage(&config, ADS1115_AIN1_GND, &voltage); // 测量AIN1对地电压
    if (ret == ADS1115_OK) {
        printf("AIN1 voltage: %.4f V\n", voltage);
    } else {
        printf("Failed to read voltage: %d\n", ret);
    }

    ret = ADS1115_ReadVoltage(&config, ADS1115_AIN2_GND, &voltage); // 测量AIN2对地电压
    if (ret == ADS1115_OK) {
        printf("AIN2 voltage: %.4f V\n", voltage);
    } else {
        printf("Failed to read voltage: %d\n", ret);
    }

    // 关闭设备
    ADS1115_Close(&config);

    return 0;
}