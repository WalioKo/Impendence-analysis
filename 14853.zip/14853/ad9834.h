#ifndef AD9834_H
#define AD9834_H

#include <gpiod.h>
#include <unistd.h>

/* AD9834控制引脚定义（根据实际硬件连接修改） */
#define FSYNC_GPIO_CHIP    "gpiochip0"
#define FSYNC_GPIO_LINE    56   // 实际GPIO号
#define SCLK_GPIO_LINE     57
#define SDATA_GPIO_LINE    58
#define RESET_GPIO_LINE    59
#define FS_GPIO_LINE       4
#define PS_GPIO_LINE       5

/* AD9834配置参数 */
#define AD9834_SYSTEM_CLOCK    75000000UL
#define FREQ_0      0
#define FREQ_1      1

/* 波形选择命令 */
#define Triangle_Wave    0x2002
#define Sine_Wave        0x2008
#define Square_Wave      0x2028

/* GPIO初始化 */
int init_gpio();

/* 微秒延时函数 */
void delay_us(unsigned int us);

/* 向AD9834写入16位数据 */
void AD9834_Write_16Bits(unsigned int data);

/* 波形选择函数 */
void AD9834_Select_Wave(unsigned int initdata);

/* 初始化AD9834 */
void AD9834_Init();

/* 设置频率 */
void AD9834_Set_Freq(unsigned char freq_number, unsigned long freq);

/* 清理GPIO资源 */
void cleanup_gpio();

#endif // AD9834_H