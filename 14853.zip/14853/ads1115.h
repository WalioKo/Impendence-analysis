/**
 * @file    ads1115.h
 * @brief   ADS1115 16位ADC驱动库（Linux平台通用实现）
 */

#ifndef __ADS1115_H__
#define __ADS1115_H__

#include <stdint.h>
#include <unistd.h>
#ifdef __cplusplus
extern "C" {
#endif

/* 默认I2C地址 */
#define ADS1115_DEFAULT_ADDR    0x48

/* 寄存器地址定义 */
#define ADS1115_REG_CONVERSION  0x00
#define ADS1115_REG_CONFIG      0x01
#define ADS1115_REG_LO_THRESH   0x02
#define ADS1115_REG_HI_THRESH   0x03

/* 输入通道配置 (MUX) */
typedef enum {
    ADS1115_AIN0_GND = 0x4000, // AIN0单端输入
    ADS1115_AIN1_GND = 0x5000, // AIN1单端输入
    ADS1115_AIN2_GND = 0x6000, // AIN2单端输入
    ADS1115_AIN3_GND = 0x7000, // AIN3单端输入
    ADS1115_AIN0_AIN1 = 0x0000 // AIN0-AIN1差分输入
} ADS1115_Channel;

/* 可编程增益配置 (PGA) */
typedef enum {
    ADS1115_PGA_6V144 = 0x0000, // ±6.144V
    ADS1115_PGA_4V096 = 0x0200, // ±4.096V
    ADS1115_PGA_2V048 = 0x0400, // ±2.048V (默认)
    ADS1115_PGA_1V024 = 0x0600, // ±1.024V
    ADS1115_PGA_0V512 = 0x0800, // ±0.512V
    ADS1115_PGA_0V256 = 0x0A00  // ±0.256V
} ADS1115_Gain;

/* 数据速率配置 (DR) */
typedef enum {
    ADS1115_DR_8SPS   = 0x0000,
    ADS1115_DR_16SPS  = 0x0020,
    ADS1115_DR_32SPS  = 0x0040,
    ADS1115_DR_64SPS  = 0x0060,
    ADS1115_DR_128SPS = 0x0080, // 默认
    ADS1115_DR_250SPS = 0x00A0,
    ADS1115_DR_475SPS = 0x00C0,
    ADS1115_DR_860SPS = 0x00E0
} ADS1115_DataRate;

/* 工作模式配置 */
typedef enum {
    ADS1115_MODE_CONTINUOUS = 0x0000, // 连续转换
    ADS1115_MODE_SINGLE     = 0x0100  // 单次转换（默认）
} ADS1115_OpMode;

/* 配置结构体 */
typedef struct {
    ADS1115_Channel channel;            //读取通道
    ADS1115_Gain gain;                  //信号增益设置
    ADS1115_DataRate data_rate;         //数据传输速率
    ADS1115_OpMode op_mode;             //模式设置
    uint8_t i2c_addr;                   //IIC地址
    int i2c_fd;                         //IIC文件描述符
} ADS1115_Config;

/* 错误代码定义 */
#define ADS1115_OK              0
#define ADS1115_ERR_I2C        -1
#define ADS1115_ERR_INVALID    -2
#define ADS1115_ERR_OPEN      -3

/**
 * @brief 打开I2C设备并初始化ADS1115
 * @param config 配置参数结构体指针
 * @param i2c_bus I2C总线编号（如：1表示/dev/i2c-1）
 * @return 错误代码
 */
int ADS1115_Open(ADS1115_Config *config, int i2c_bus);

/**
 * @brief 关闭I2C设备
 * @param config 配置参数结构体指针
 */
void ADS1115_Close(ADS1115_Config *config);

/**
 * @brief 读取原始ADC值
 * @param config 配置参数结构体指针
 * @param channel 指定通道
 * @param[out] raw_value 输出原始值指针
 * @return 错误代码
 */
int ADS1115_ReadRaw(ADS1115_Config *config, ADS1115_Channel channel, int16_t *raw_value);

/**
 * @brief 读取实际电压值
 * @param config 配置参数结构体指针
 * @param channel 指定通道
 * @param[out] voltage 输出电压值指针（单位：伏特）
 * @return 错误代码
 */
int ADS1115_ReadVoltage(ADS1115_Config *config, ADS1115_Channel channel, float *voltage);

#ifdef __cplusplus
}
#endif

#endif /* __ADS1115_H__ */