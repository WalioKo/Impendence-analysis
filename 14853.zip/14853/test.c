
#include <unistd.h>
#include <math.h>
#include <gpiod.h>
#include "ads1115.h"
#include "ad9834.h"

void Calcu_Im(float VPHS,float VMAG,float Ref_R);
struct gpiod_chip *chip;
struct gpiod_line *line40, *line41;


int main() 
{
    // 初始化ADS1115
	float VMAG,VPHS,Ref_R;
    ADS1115_Config config = {
        .channel = ADS1115_AIN0_GND,
        .gain = ADS1115_PGA_4V096,
        .data_rate = ADS1115_DR_860SPS,
        .op_mode = ADS1115_MODE_SINGLE,
        .i2c_addr = ADS1115_DEFAULT_ADDR
    };
	
	
	chip = gpiod_chip_open_by_name("gpiochip0");
    line40 = gpiod_chip_get_line(chip, 40);
    line41 = gpiod_chip_get_line(chip, 41);
    if (!line40 || !line41) {
        perror("获取GPIO引脚失败");
        gpiod_chip_close(chip);
        return 1;
    }
    if (gpiod_line_request_output(line40, "example", 0) < 0 || 
        gpiod_line_request_output(line41, "example", 0) < 0) {
        perror("配置GPIO输出模式失败");
        gpiod_chip_close(chip);
        return 1;
    }
    gpiod_line_set_value(line40, 1);  // GPIO40 高电平
    gpiod_line_set_value(line41, 1);  // GPIO41 低电平
	

    if (ADS1115_Open(&config, 1) != ADS1115_OK) {
        printf("初始化失败\n");
        return -1;
    }
	
    printf("ADS1115初始化成功\n");
	
	AD9834_Init();
	AD9834_Select_Wave(Sine_Wave);
	AD9834_Set_Freq(FREQ_0, 2000000);
	ADS1115_ReadVoltage(&config, ADS1115_AIN0_GND, &VPHS);
	ADS1115_ReadVoltage(&config, ADS1115_AIN1_GND, &VMAG);
	Ref_R=10000;
	printf("VPHS:%f VMAG:%f",VPHS,VMAG);
	Calcu_Im( VPHS, VMAG, Ref_R);
	

    // 关闭设备

    //gpiod_line_set_value(line40, 0);  // 关闭前设置为低电平
    //gpiod_line_set_value(line41, 0);  // 关闭前设置为低电平
    //gpiod_line_release(line40);
    //gpiod_line_release(line41);
    //gpiod_chip_close(chip);
	ADS1115_Close(&config);
    return 0;
}

void Calcu_Im(float VPHS,float VMAG,float Ref_R)
{
	float Radio,R,Ph,Z;
	
	Radio=32.885*VMAG-30.528;
	Z=Ref_R*pow(10,Radio/20);
	Ph=-94.169*VPHS+178.21;
	R=Z*cos(Ph);
	printf("Z：%f R:%f Ph%f \n",Z,R,Ph);
	
}