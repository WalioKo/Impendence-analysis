/**
 * @file    ads1115.c
 * @brief   ADS1115驱动实现（Linux I2C接口）
 */

#include "ads1115.h"
#include <linux/i2c-dev.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <unistd.h>  

/* 内部函数声明 */
static float _get_full_scale_voltage(ADS1115_Gain gain);
static uint8_t _calculate_delay_ms(ADS1115_DataRate data_rate);
static int _i2c_write(int fd, uint8_t addr, uint8_t *data, uint16_t len);
static int _i2c_read(int fd, uint8_t addr, uint8_t *data, uint16_t len);

int ADS1115_Open(ADS1115_Config *config, int i2c_bus) {
    /* 参数校验 */
    if (config == NULL) {
        return ADS1115_ERR_INVALID;
    }

    /* 打开I2C设备 */
    char filename[20];
    snprintf(filename, sizeof(filename), "/dev/i2c-%d", i2c_bus);
    int fd = open(filename, O_RDWR);
    if (fd < 0) {
        perror("Failed to open I2C device");
        return ADS1115_ERR_OPEN;
    }

    /* 设置从机地址 */
    if (ioctl(fd, I2C_SLAVE, config->i2c_addr) < 0) {
        perror("Failed to set I2C slave address");
        close(fd);
        return ADS1115_ERR_I2C;
    }

    config->i2c_fd = fd;

    /* 初始化配置 */
    uint16_t config_val = config->channel | 
                         config->gain | 
                         config->op_mode | 
                         config->data_rate | 
                         0x0003; // 禁用比较器

    uint8_t data[3] = {
        ADS1115_REG_CONFIG,
        (uint8_t)(config_val >> 8),
        (uint8_t)(config_val)
    };

    if (_i2c_write(fd, config->i2c_addr, data, sizeof(data)) != 0) {
        close(fd);
        return ADS1115_ERR_I2C;
    }

    return ADS1115_OK;
}

void ADS1115_Close(ADS1115_Config *config) {
    if (config != NULL && config->i2c_fd >= 0) {
        close(config->i2c_fd);
        config->i2c_fd = -1;
    }
}

int ADS1115_ReadRaw(ADS1115_Config *config, ADS1115_Channel channel, int16_t *raw_value) {
    if (config == NULL || raw_value == NULL || config->i2c_fd < 0) {
        return ADS1115_ERR_INVALID;
    }

    /* 临时配置（启动单次转换） */
    uint16_t temp_config = channel | 
                          config->gain | 
                          config->op_mode | 
                          config->data_rate | 
                          0x8003; // OS=1启动转换

    uint8_t config_data[3] = {
        ADS1115_REG_CONFIG,
        (uint8_t)(temp_config >> 8),
        (uint8_t)(temp_config)
    };

    if (_i2c_write(config->i2c_fd, config->i2c_addr, config_data, sizeof(config_data)) != 0) {
        return ADS1115_ERR_I2C;
    }

    /* 等待转换完成 */
    usleep(_calculate_delay_ms(config->data_rate) * 1000);

    /* 读取转换结果 */
    uint8_t reg_addr = ADS1115_REG_CONVERSION;
    if (_i2c_write(config->i2c_fd, config->i2c_addr, &reg_addr, 1) != 0) {
        return ADS1115_ERR_I2C;
    }

    uint8_t raw_data[2];
    if (_i2c_read(config->i2c_fd, config->i2c_addr, raw_data, sizeof(raw_data)) != 0) {
        return ADS1115_ERR_I2C;
    }

    *raw_value = (int16_t)((raw_data[0] << 8) | raw_data[1]);
    return ADS1115_OK;
}

int ADS1115_ReadVoltage(ADS1115_Config *config, ADS1115_Channel channel, float *voltage) {
    int16_t raw;
    int ret = ADS1115_ReadRaw(config, channel, &raw);
    if (ret != ADS1115_OK) {
        return ret;
    }

    float full_scale = _get_full_scale_voltage(config->gain);
    *voltage = (raw * full_scale) / 32768.0f;
    return ADS1115_OK;
}

/* 静态函数实现 */
static float _get_full_scale_voltage(ADS1115_Gain gain) {
    switch(gain) {
        case ADS1115_PGA_6V144: return 6.144f;
        case ADS1115_PGA_4V096: return 4.096f;
        case ADS1115_PGA_2V048: return 2.048f;
        case ADS1115_PGA_1V024: return 1.024f;
        case ADS1115_PGA_0V512: return 0.512f;
        case ADS1115_PGA_0V256: return 0.256f;
        default: return 2.048f;
    }
}

static uint8_t _calculate_delay_ms(ADS1115_DataRate data_rate) {
    uint16_t sps = 8 << (data_rate >> 5);
    return (uint8_t)(1100 / sps) + 1;
}


static int _i2c_write(int fd, uint8_t addr __attribute__((unused)), uint8_t *data, uint16_t len) {
    if (write(fd, data, len) != len) {
        perror("I2C write failed");
        return -1;
    }
    return 0;
}


static int _i2c_read(int fd, uint8_t addr __attribute__((unused)), uint8_t *data, uint16_t len) {
    if (read(fd, data, len) != len) {
        perror("I2C read failed");
        return -1;
    }
    return 0;
}