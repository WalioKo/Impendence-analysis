#include "menu.h"
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <locale.h>

// 全局变量
SDL_Renderer* renderer = NULL;
TTF_Font* font_small = NULL;
TTF_Font* font_medium = NULL;
TTF_Font* font_large = NULL;

// 频率预设值
const double freq_steps[FREQ_STEPS] = {100,10000,100000, 500000, 1000000, 10000000, 30000000};

// 设置项名称
const char* setting_names[SETTING_ITEMS] = {
    "频率设置",
    "坐标系设置",
    "测试模式"
};

// 颜色定义
const SDL_Color BLACK = {0, 0, 0, 255};
const SDL_Color WHITE = {255, 255, 255, 255};
const SDL_Color RED = {255, 0, 0, 255};
const SDL_Color BLUE = {0, 0, 255, 255};
const SDL_Color GREEN = {0, 180, 0, 255};
const SDL_Color ORANGE = {255, 165, 0, 255};
const SDL_Color GRAY = {150, 150, 150, 255};
const SDL_Color DARK_GRAY = {100, 100, 100, 255};
const SDL_Color HIGHLIGHT = {255, 215, 0, 255};
const SDL_Color DARK_BLUE = {0, 0, 128, 255};
const SDL_Color LIGHT_GRAY = {220, 220, 220, 255};
const SDL_Color PANEL_BG = {240, 245, 250, 255};
const SDL_Color PARAM_BG = {230, 235, 240, 255};

// 测量模式名称
const char* measurement_mode_names[] = {
    "阻抗曲线",
    "电容测量",
    "电感测量",
    "幅频曲线",
    "相频曲线"
};

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

// 比较函数
static int compare_double(const void* a, const void* b) {
    double diff = *(const double*)a - *(const double*)b;
    return (diff > 0) ? 1 : ((diff < 0) ? -1 : 0);
}


// 坐标系类型名称
const char* coord_type_names[] = {
    "线性",
    "对数"
};

void init_menu_system(SDL_Renderer* sdl_renderer, 
                     TTF_Font* small_font, 
                     TTF_Font* medium_font, 
                     TTF_Font* large_font) {
    renderer = sdl_renderer;
    font_small = small_font;
    font_medium = medium_font;
    font_large = large_font;
}

void render_text(TTF_Font* font, const char* text, int x, int y, SDL_Color color) {
    if (!font || !text) return;
    
    SDL_Surface* surface = TTF_RenderUTF8_Blended(font, text, color);
    if (!surface) {
        printf("文本渲染失败: %s\n", TTF_GetError());
        return;
    }
    
    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
    if (!texture) {
        printf("纹理创建失败: %s\n", SDL_GetError());
        SDL_FreeSurface(surface);
        return;
    }
    
    SDL_Rect rect = {x, y, surface->w, surface->h};
    SDL_RenderCopy(renderer, texture, NULL, &rect);
    
    SDL_FreeSurface(surface);
    SDL_DestroyTexture(texture);
}

// 新增函数：自适应文本渲染（在矩形区域内居中或截断）
void render_text_fit(TTF_Font* font, const char* text, SDL_Rect rect, SDL_Color color) {
    if (!font || !text) return;
    
    int text_width, text_height;
    TTF_SizeUTF8(font, text, &text_width, &text_height);
    
    // 如果文本宽度小于矩形宽度，直接居中渲染
    if (text_width <= rect.w) {
        int x = rect.x + (rect.w - text_width) / 2;
        int y = rect.y + (rect.h - text_height) / 2;
        render_text(font, text, x, y, color);
    } 
    // 如果文本太长，尝试截断并添加省略号
    else {
        char truncated[64];
        // 估算最大字符数（留出省略号空间）
        int max_chars = (rect.w * strlen(text)) / text_width;
        if (max_chars > 3) {
            snprintf(truncated, sizeof(truncated), "%.*s...", max_chars - 3, text);
            // 检查截断后的文本宽度
            TTF_SizeUTF8(font, truncated, &text_width, &text_height);
            if (text_width > rect.w) {
                // 如果仍然太长，继续缩短
                max_chars -= 2;
                snprintf(truncated, sizeof(truncated), "%.*s...", max_chars - 3, text);
            }
        } else {
            // 空间非常小，只显示省略号
            strcpy(truncated, "...");
        }
        
        // 渲染截断文本
        int x = rect.x + (rect.w - text_width) / 2;
        int y = rect.y + (rect.h - text_height) / 2;
        render_text(font, truncated, x, y, color);
    }
}

void draw_graph(AppState *state) {
    int screen_width, screen_height;
    SDL_GetWindowSize(state->window, &screen_width, &screen_height);
    
    // 图表区域设置
    int graph_width = screen_width * 3 / 4 - 70;
    int graph_height = screen_height - 260;
    int graph_x = 50;
    int graph_y = 100;
    
    // 绘制图表背景
    SDL_SetRenderDrawColor(renderer, 245, 245, 250, 255);
    SDL_Rect graph_rect = {graph_x, graph_y, graph_width, graph_height};
    SDL_RenderFillRect(renderer, &graph_rect);
    
    // 绘制坐标轴
    SDL_SetRenderDrawColor(renderer, 50, 50, 50, 255);
    SDL_RenderDrawLine(renderer, graph_x, graph_y + graph_height, 
                      graph_x + graph_width, graph_y + graph_height); // X轴
    SDL_RenderDrawLine(renderer, graph_x, graph_y, 
                      graph_x, graph_y + graph_height); // Y轴
    
    // 设置Y轴标签
    const char* y_label = "";
    switch (state->measurement_mode) {
        case IMPEDANCE_MODE: y_label = "阻抗/Ω"; break;
        case CAPACITANCE_MODE: y_label = "电容"; break; // 单位在刻度处动态显示
        case INDUCTANCE_MODE: y_label = "电感/H"; break;
        case MAGNITUDE_MODE: y_label = "幅度/dB"; break;
        case PHASE_MODE: y_label = "相位/rad"; break;
    }
    
    // 绘制Y轴标签
    int text_width, text_height;
    TTF_SizeUTF8(font_small, y_label, &text_width, &text_height);
    render_text(font_small, y_label, 0, graph_y - 30, DARK_BLUE);
    
    // 计算数据范围
    double min_value = state->data[0];
    double max_value = state->data[0];
    for (int i = 1; i < DATA_POINTS; i++) {
        if (!isnan(state->data[i])) {
            if (state->data[i] < min_value) min_value = state->data[i];
            if (state->data[i] > max_value) max_value = state->data[i];
        }
    }
    
    // 特殊处理各模式的显示范围
    switch(state->measurement_mode) {
        case CAPACITANCE_MODE: {
            // 电容模式：不强制归零，自动调整范围
            if (max_value <= min_value) {
                max_value = min_value + 1e-12; // 防止除零
            }
            
            // 如果数据范围太小（小于10%），自动扩展
            if ((max_value - min_value) < 0.1 * fabs(max_value)) {
                double center = (max_value + min_value) / 2;
                double range = fabs(max_value - min_value);
                min_value = center - 0.6 * range;
                max_value = center + 0.6 * range;
            }
            break;
        }
        case PHASE_MODE: {
            // 相位模式：对称显示
            if (fabs(min_value) > fabs(max_value)) max_value = -min_value;
            else min_value = -max_value;
            if (max_value < 0.1) {
                min_value = -1.0;
                max_value = 1.0;
            }
            break;
        }
        default: {
            // 其他模式：从0开始
            min_value = 0;
            if (max_value < min_value + 0.1) max_value = min_value + 0.1;
            break;
        }
    }
    
    // 绘制X轴刻度
    for (int i = 0; i <= 5; i++) {
        int x_pos = graph_x + i * graph_width / 5;
        SDL_RenderDrawLine(renderer, x_pos, graph_y + graph_height - 5, 
                          x_pos, graph_y + graph_height + 5);
        
        double freq_value;
        char label[16];
        
        if (state->coord == LINEAR) {
            freq_value = state->start_freq + (i / 5.0) * (state->end_freq - state->start_freq);
            
            if (freq_value >= 1e6) {
                snprintf(label, sizeof(label), "%.0fM", freq_value / 1e6);
            } else if (freq_value >= 1000) {
                snprintf(label, sizeof(label), "%.0fk", freq_value / 1000);
            } else {
                snprintf(label, sizeof(label), "%.0f", freq_value);
            }
        } else {
            freq_value = state->start_freq * pow(10, (i / 5.0) * log10(state->end_freq / state->start_freq));
            
            if (freq_value < 1000) {
                snprintf(label, sizeof(label), "%.0f", freq_value);
            } else if (freq_value < 1e6) {
                snprintf(label, sizeof(label), "%.0fk", freq_value / 1000);
            } else {
                snprintf(label, sizeof(label), "%.0fM", freq_value / 1e6);
            }
        }
        
        TTF_SizeUTF8(font_small, label, &text_width, &text_height);
        render_text(font_small, label, x_pos - text_width/2, graph_y + graph_height + 10, DARK_BLUE);
    }
    
    // 绘制Y轴刻度
    for (int i = 0; i <= 5; i++) {
        int y_pos = graph_y + graph_height - i * graph_height / 5;
        
        // 绘制网格线
        SDL_SetRenderDrawColor(renderer, 220, 220, 220, 255);
        SDL_RenderDrawLine(renderer, graph_x, y_pos, graph_x + graph_width, y_pos);
        
        // 绘制刻度线
        SDL_SetRenderDrawColor(renderer, 50, 50, 50, 255);
        SDL_RenderDrawLine(renderer, graph_x - 5, y_pos, graph_x + 5, y_pos);
        
        double value = min_value + i * (max_value - min_value) / 5;
        char label[32];  // 增大缓冲区以容纳更多字符
        char unit[8] = "";
        double display_value = value;
        
        // 改进的单位转换逻辑
        switch (state->measurement_mode) {
            case IMPEDANCE_MODE:
                if (fabs(value) >= 1e6) {
                    display_value = value / 1e6;
                    strcpy(unit, "MΩ");
                } else if (fabs(value) >= 1000) {
                    display_value = value / 1000;
                    strcpy(unit, "kΩ");
                } else {
                    strcpy(unit, "Ω");
                }
                break;
                
            case CAPACITANCE_MODE: {
                // 电容值的智能单位转换
                double abs_value = fabs(value);
                if (abs_value >= 1.0) {
                    strcpy(unit, "F");
                } else if (abs_value >= 1e-3) {
                    display_value = value * 1e3;
                    strcpy(unit, "mF");
                } else if (abs_value >= 1e-6) {
                    display_value = value * 1e6;
                    strcpy(unit, "μF");
                } else if (abs_value >= 1e-9) {
                    display_value = value * 1e9;
                    strcpy(unit, "nF");
                } else {
                    display_value = value * 1e12;
                    strcpy(unit, "pF");
                }
                break;
            }
                
            case INDUCTANCE_MODE:
                if (fabs(value) >= 1) {
                    strcpy(unit, "H");
                } else if (fabs(value) >= 1e-3) {
                    display_value = value * 1e3;
                    strcpy(unit, "mH");
                } else {
                    display_value = value * 1e6;
                    strcpy(unit, "μH");
                }
                break;
                
            default:
                strcpy(unit, "");
                break;
        }
        
        // 智能数值格式化
        if (fabs(display_value) < 0.001 && display_value != 0) {
            // 极小值使用科学计数法
            snprintf(label, sizeof(label), "%.1e%s", display_value, unit);
        } else if (fabs(display_value) < 1) {
            // 小数值保留更多小数位
            int decimal_places = (int)fmax(3, -log10(fabs(display_value)) + 1);
            decimal_places = fmin(decimal_places, 6);
            char format[16];
            snprintf(format, sizeof(format), "%%.%df%%s", decimal_places);
            snprintf(label, sizeof(label), format, display_value, unit);
        } else if (fabs(display_value) < 1000) {
            snprintf(label, sizeof(label), "%.2f%s", display_value, unit);
        } else {
            snprintf(label, sizeof(label), "%.0f%s", display_value, unit);
        }
        
        // 渲染Y轴标签
        TTF_SizeUTF8(font_small, label, &text_width, &text_height);
        render_text(font_small, label, graph_x - text_width - 8, y_pos - text_height/2, DARK_BLUE);
    }
    
    // 绘制数据曲线
    SDL_SetRenderDrawColor(renderer, 0, 100, 200, 255);
    int prev_x = graph_x;
    int prev_y = graph_y + graph_height - (int)((state->data[0] - min_value) * graph_height / (max_value - min_value));
    
    for (int i = 1; i < DATA_POINTS; i++) {
        int x = graph_x + (int)((double)i / (DATA_POINTS-1) * graph_width);
        int y = graph_y + graph_height - (int)((state->data[i] - min_value) * graph_height / (max_value - min_value));
        
        // 确保坐标在图表范围内
        y = (y < graph_y) ? graph_y : (y > graph_y + graph_height) ? graph_y + graph_height : y;
        
        // 绘制线段
        SDL_RenderDrawLine(renderer, prev_x, prev_y, x, y);
        prev_x = x;
        prev_y = y;
    }
    
    // 在VIEW_MODE下绘制参考点标记
    if (state->mode == VIEW_MODE) {
        // 确保光标位置在图表区域内
        state->cursor_x = (state->cursor_x < graph_x) ? graph_x : 
                         (state->cursor_x > graph_x + graph_width) ? graph_x + graph_width : state->cursor_x;
        state->cursor_y = (state->cursor_y < graph_y) ? graph_y : 
                         (state->cursor_y > graph_y + graph_height) ? graph_y + graph_height : state->cursor_y;
        
        // 绘制十字线
        SDL_SetRenderDrawColor(renderer, 255, 0, 0, 150);
        SDL_RenderDrawLine(renderer, graph_x, state->cursor_y, graph_x + graph_width, state->cursor_y);
        SDL_RenderDrawLine(renderer, state->cursor_x, graph_y, state->cursor_x, graph_y + graph_height);
        
        // 绘制中心点
        SDL_Rect point_rect = {state->cursor_x - 5, state->cursor_y - 5, 10, 10};
        SDL_SetRenderDrawColor(renderer, 255, 255, 0, 255);
        SDL_RenderFillRect(renderer, &point_rect);
        SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
        SDL_RenderDrawRect(renderer, &point_rect);
    }
}


void draw_settings_list(AppState *state, int panel_x, int panel_width, int start_y) {
    int item_height = 70;
    int padding = 8;
    
    for (int i = 0; i < SETTING_ITEMS; i++) {
        int y = start_y + i * item_height;
        
        // 设置项背景
        SDL_Color bg_color = (i == state->selected_setting) ? 
            (SDL_Color){240, 245, 250, 255} : (SDL_Color){220, 230, 240, 255};
        
        SDL_SetRenderDrawColor(renderer, bg_color.r, bg_color.g, bg_color.b, bg_color.a);
        SDL_Rect setting_rect = {panel_x + 10, y, panel_width - 20, item_height - padding};
        SDL_RenderFillRect(renderer, &setting_rect);
        
        // 设置项边框
        SDL_SetRenderDrawColor(renderer, 180, 180, 180, 255);
        SDL_RenderDrawRect(renderer, &setting_rect);
        
        // 设置项标题
        SDL_Color title_color = (i == state->selected_setting) ? ORANGE : DARK_BLUE;
        int text_width, text_height;
        TTF_SizeUTF8(font_medium, setting_names[i], &text_width, &text_height);
        render_text(font_medium, setting_names[i], panel_x + (panel_width - text_width)/2, y - 5, title_color);
        
        // 设置项值
        const char* value_text = "";
        char value_buffer[64];
        switch (i) {
            case FREQUENCY_SETTING: {
                sprintf(value_buffer, "%.0f Hz - %.0f Hz", state->start_freq, state->end_freq);
                value_text = value_buffer;
                break;
            }
            case COORDINATE_SETTING:
                value_text = coord_type_names[state->coord];
                break;
            case TEST_MODE_SETTING:
                value_text = measurement_mode_names[state->measurement_mode];
                break;
        }
        
        // 参数值背景框
        SDL_SetRenderDrawColor(renderer, 250, 250, 250, 255);
        SDL_Rect value_rect = {panel_x + 20, y + 35, panel_width - 40, 25};
        SDL_RenderFillRect(renderer, &value_rect);
        SDL_SetRenderDrawColor(renderer, 200, 200, 200, 255);
        SDL_RenderDrawRect(renderer, &value_rect);
        
        // 优化：在参数框内居中显示文本（使用新函数）
        SDL_Color value_color = (i == state->selected_setting) ? BLACK : DARK_GRAY;
        render_text_fit(font_small, value_text, value_rect, value_color);
    }
}

void draw_frequency_settings(AppState *state, int panel_x, int panel_width, int y_pos) {
    // 增加背景框高度以容纳两行
    SDL_SetRenderDrawColor(renderer, 240, 245, 250, 255);
    SDL_Rect bg_rect = {panel_x + 10, y_pos, panel_width - 20, 110}; // 高度增加
    SDL_RenderFillRect(renderer, &bg_rect);
    SDL_SetRenderDrawColor(renderer, 180, 180, 255, 255);
    SDL_RenderDrawRect(renderer, &bg_rect);
    
    // 标题
    int text_width, text_height;
    TTF_SizeUTF8(font_medium, "频率设置", &text_width, &text_height);
    render_text(font_medium, "频率设置", panel_x + (panel_width - text_width)/2, y_pos + 10, DARK_BLUE);
    
    // 起始频率设置框 - 放在第一行
    SDL_SetRenderDrawColor(renderer, 250, 250, 250, 255);
    SDL_Rect start_rect = {panel_x + 20, y_pos + 40, panel_width - 40, 25}; // 宽度增加
    SDL_RenderFillRect(renderer, &start_rect);
    SDL_SetRenderDrawColor(renderer, 
        (state->freq_setting == START_FREQ) ? ORANGE.r : 200,
        (state->freq_setting == START_FREQ) ? ORANGE.g : 200,
        (state->freq_setting == START_FREQ) ? ORANGE.b : 200,
        255);
    SDL_RenderDrawRect(renderer, &start_rect);
    
    char freq_text[64];
    sprintf(freq_text, "起始频率: %.0f Hz", state->start_freq);
    
    // 在矩形框内居中显示文本
    render_text_fit(font_small, freq_text, start_rect, 
                  (state->freq_setting == START_FREQ) ? ORANGE : BLACK);
    
    // 终止频率设置框 - 放在第二行
    SDL_SetRenderDrawColor(renderer, 250, 250, 250, 255);
    SDL_Rect end_rect = {panel_x + 20, y_pos + 75, panel_width - 40, 25}; // 宽度增加
    SDL_RenderFillRect(renderer, &end_rect);
    SDL_SetRenderDrawColor(renderer, 
        (state->freq_setting == END_FREQ) ? ORANGE.r : 200,
        (state->freq_setting == END_FREQ) ? ORANGE.g : 200,
        (state->freq_setting == END_FREQ) ? ORANGE.b : 200,
        255);
    SDL_RenderDrawRect(renderer, &end_rect);
    
    sprintf(freq_text, "终止频率: %.0f Hz", state->end_freq);
    
    // 在矩形框内居中显示文本
    render_text_fit(font_small, freq_text, end_rect, 
                  (state->freq_setting == END_FREQ) ? ORANGE : BLACK);
}

void draw_coord_settings(AppState *state, int panel_x, int panel_width, int y_pos) {
    // 背景框（增加高度以容纳两个选项）
    SDL_SetRenderDrawColor(renderer, 240, 245, 250, 255);
    SDL_Rect bg_rect = {panel_x + 10, y_pos, panel_width - 20, 100}; // 高度增加
    SDL_RenderFillRect(renderer, &bg_rect);
    SDL_SetRenderDrawColor(renderer, 180, 180, 180, 255);
    SDL_RenderDrawRect(renderer, &bg_rect);
    
    // 标题
    int text_width, text_height;
    TTF_SizeUTF8(font_medium, "坐标系设置", &text_width, &text_height);
    render_text(font_medium, "坐标系设置", panel_x + (panel_width - text_width)/2, y_pos + 10, DARK_BLUE);
    
    // 绘制两个选项：线性和对数
    int button_height = 30;
    int button_width = (panel_width - 60) / 2; // 两个按钮，中间留10像素间距
    
    // 线性坐标按钮
    SDL_Rect linear_rect = {panel_x + 20, y_pos + 40, button_width, button_height};
    // 根据当前坐标系类型设置颜色
    if (state->coord == LINEAR) {
        SDL_SetRenderDrawColor(renderer, HIGHLIGHT.r, HIGHLIGHT.g, HIGHLIGHT.b, 255);
    } else {
        SDL_SetRenderDrawColor(renderer, 220, 220, 220, 255);
    }
    SDL_RenderFillRect(renderer, &linear_rect);
    // 边框
    SDL_SetRenderDrawColor(renderer, 150, 150, 150, 255);
    SDL_RenderDrawRect(renderer, &linear_rect);
    // 文本
    render_text_fit(font_small, "线性", linear_rect, state->coord == LINEAR ? ORANGE : BLACK);
    
    // 对数坐标按钮
    SDL_Rect log_rect = {panel_x + 30 + button_width, y_pos + 40, button_width, button_height};
    if (state->coord == LOGARITHMIC) {
        SDL_SetRenderDrawColor(renderer, HIGHLIGHT.r, HIGHLIGHT.g, HIGHLIGHT.b, 255);
    } else {
        SDL_SetRenderDrawColor(renderer, 220, 220, 220, 255);
    }
    SDL_RenderFillRect(renderer, &log_rect);
    // 边框
    SDL_SetRenderDrawColor(renderer, 150, 150, 150, 255);
    SDL_RenderDrawRect(renderer, &log_rect);
    render_text_fit(font_small, "对数", log_rect, state->coord == LOGARITHMIC ? ORANGE : BLACK);
}

void draw_test_mode_selection(AppState *state, int panel_x, int panel_width, int y_pos) {
    // 背景框
    SDL_SetRenderDrawColor(renderer, 240, 245, 250, 255);
    SDL_Rect mode_rect = {panel_x + 10, y_pos, panel_width - 20, 220};
    SDL_RenderFillRect(renderer, &mode_rect);
    SDL_SetRenderDrawColor(renderer, 180, 180, 180, 255);
    SDL_RenderDrawRect(renderer, &mode_rect);
    
    // 标题
    int text_width, text_height;
    TTF_SizeUTF8(font_medium, "选择测试模式", &text_width, &text_height);
    render_text(font_medium, "选择测试模式", panel_x + (panel_width - text_width)/2, y_pos, DARK_BLUE);
    
    // 当前选择提示
    SDL_SetRenderDrawColor(renderer, 250, 250, 250, 255);
    SDL_Rect current_rect = {panel_x + 20, y_pos + 35, panel_width - 40, 25};
    SDL_RenderFillRect(renderer, &current_rect);
    SDL_SetRenderDrawColor(renderer, 200, 200, 200, 255);
    SDL_RenderDrawRect(renderer, &current_rect);
    
    char current_text[32];
    sprintf(current_text, "当前: %s", measurement_mode_names[state->measurement_mode]);
    TTF_SizeUTF8(font_small, current_text, &text_width, &text_height);
    render_text(font_small, current_text, panel_x + (panel_width - text_width)/2, y_pos + 35, BLACK);
    
    // 绘制5个测试模式选项
    for (int i = 0; i < 5; i++) {
        // 选项背景框（使用HIGHLIGHT替代HIGHLIGHT_YELLOW）
        SDL_SetRenderDrawColor(renderer, 
            (i == state->selected_test_mode) ? HIGHLIGHT.r : 250,
            (i == state->selected_test_mode) ? HIGHLIGHT.g : 250,
            (i == state->selected_test_mode) ? HIGHLIGHT.b : 250,
            255);
        SDL_Rect bg_rect = {panel_x + 35, y_pos + 70 + i * 30, panel_width - 70, 25};
        SDL_RenderFillRect(renderer, &bg_rect);
        
        // 选项边框（使用ORANGE替代HIGHLIGHT_ORANGE）
        SDL_SetRenderDrawColor(renderer, 
            (i == state->selected_test_mode) ? ORANGE.r : 200,
            (i == state->selected_test_mode) ? ORANGE.g : 200,
            (i == state->selected_test_mode) ? ORANGE.b : 200,
            255);
        SDL_RenderDrawRect(renderer, &bg_rect);
        
        // 测试模式名称 - 使用新的居中函数
        render_text_fit(font_small, measurement_mode_names[i], bg_rect, 
                      (i == state->selected_test_mode) ? ORANGE : DARK_BLUE);
    }
}
void draw_reference_point(AppState *state, int panel_x, int panel_width, int y_pos) {
    // 获取窗口尺寸
    int screen_width, screen_height;
    SDL_GetWindowSize(state->window, &screen_width, &screen_height);
    
    // 图表区域参数（必须与draw_graph()保持一致）
    int graph_width = screen_width * 3/4 - 70;
    int graph_height = screen_height - 260;
    int graph_x = 50;
    int graph_y = 100;  // 添加缺失的graph_y定义
    
    // 参考点信息框背景
    SDL_SetRenderDrawColor(renderer, 250, 250, 230, 255);
    SDL_Rect ref_rect = {panel_x + 10, y_pos, panel_width - 20, 100};
    SDL_RenderFillRect(renderer, &ref_rect);
    
    // 边框
    SDL_SetRenderDrawColor(renderer, 0, 0, 128, 255);
    SDL_RenderDrawRect(renderer, &ref_rect);

    // 标题
    int text_width, text_height;
    const char* title = "参考点信息";
    TTF_SizeUTF8(font_medium, title, &text_width, &text_height);
    render_text(font_medium, title, 
               panel_x + (panel_width - text_width)/2, 
               y_pos, 
               DARK_BLUE);

    // 计算归一化位置（考虑图表边距）
    double norm_x = (double)(state->cursor_x - graph_x) / graph_width;
    norm_x = (norm_x < 0) ? 0 : (norm_x > 1) ? 1 : norm_x;
    
    // 根据坐标类型计算实际频率
    double freq_value;
    if (state->coord == LINEAR) {
        freq_value = state->start_freq + norm_x * (state->end_freq - state->start_freq);
    } else {
        freq_value = state->start_freq * pow(10, norm_x * log10(state->end_freq/state->start_freq));
    }
    
    // 计算归一化Y位置（使用已定义的graph_y）
    double norm_y = (double)(state->cursor_y - graph_y) / graph_height;
    norm_y = (norm_y < 0) ? 0 : (norm_y > 1) ? 1 : norm_y;
    
    // 计算数据范围（与draw_graph()逻辑一致）
    double min_val = state->data[0], max_val = state->data[0];
    for (int i = 1; i < DATA_POINTS; i++) {
        if (state->data[i] < min_val) min_val = state->data[i];
        if (state->data[i] > max_val) max_val = state->data[i];
    }
    
    // 特殊处理各模式的范围
    switch(state->measurement_mode) {
        case PHASE_MODE:
            if (fabs(min_val) > fabs(max_val)) max_val = -min_val;
            else min_val = -max_val;
            break;
        default:
            min_val = 0;
            if (max_val < 0.1) max_val = 0.1;
            break;
    }
    
    double measured_value = min_val + (1.0 - norm_y) * (max_val - min_val);

    // 信息显示区域
    SDL_SetRenderDrawColor(renderer, 240, 245, 255, 255);
    SDL_Rect info_rect = {panel_x + 15, y_pos + 35, panel_width - 30, 55};
    SDL_RenderFillRect(renderer, &info_rect);
    SDL_SetRenderDrawColor(renderer, 180, 180, 180, 255);
    SDL_RenderDrawRect(renderer, &info_rect);

    // 格式化频率显示（自动选择单位）
    char freq_str[32];
    if (freq_value < 1000) {
        sprintf(freq_str, "频率: %.2f Hz", freq_value);
    } else if (freq_value < 1e6) {
        sprintf(freq_str, "频率: %.3f kHz", freq_value/1e3);
    } else {
        sprintf(freq_str, "频率: %.3f MHz", freq_value/1e6);
    }
    
    // 格式化测量值显示（根据模式）
    char value_str[32];
    switch(state->measurement_mode) {
        case IMPEDANCE_MODE:
            sprintf(value_str, "阻抗: %.2f Ω", measured_value);
            break;
        case CAPACITANCE_MODE:
            if (fabs(measured_value) >= 1e-3) {
                sprintf(value_str, "电容: %.3f mF", measured_value);
            } else if (fabs(measured_value) >= 1e-6) {
                sprintf(value_str, "电容: %.3f μF", measured_value*1e3);
            } else if (fabs(measured_value) >= 1e-9) {
                sprintf(value_str, "电容: %.3f nF", measured_value*1e6);
            } else {
                sprintf(value_str, "电容: %.3f pF", measured_value*1e9);
            }
            break;
        case INDUCTANCE_MODE:
            if (fabs(measured_value) >= 1) {
                sprintf(value_str, "电感: %.3f H", measured_value);
            } else if (fabs(measured_value) >= 1e-3) {
                sprintf(value_str, "电感: %.3f mH", measured_value*1e3);
            } else {
                sprintf(value_str, "电感: %.3f μH", measured_value*1e6);
            }
            break;
        case MAGNITUDE_MODE:
            sprintf(value_str, "幅度: %.2f dB", measured_value);
            break;
        case PHASE_MODE:
            sprintf(value_str, "相位: %.3f rad", measured_value);
            break;
    }

    // 渲染文本
    TTF_SizeUTF8(font_small, freq_str, &text_width, &text_height);
    int line_height = text_height + 5;
    render_text(font_small, freq_str, 
               info_rect.x + (info_rect.w - text_width)/2, 
               info_rect.y + (info_rect.h/2 - line_height), 
               BLACK);

    TTF_SizeUTF8(font_small, value_str, &text_width, &text_height);
    render_text(font_small, value_str, 
               info_rect.x + (info_rect.w - text_width)/2, 
               info_rect.y + (info_rect.h/2), 
               BLACK);

    // 光标指示器
    SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
    SDL_Point cursor_indicator[3] = {
        {panel_x + panel_width/2 - 5, y_pos + 35},
        {panel_x + panel_width/2 + 5, y_pos + 35},
        {panel_x + panel_width/2, y_pos + 25}
    };
    SDL_RenderDrawLines(renderer, cursor_indicator, 3);
}
void draw_main_ui(AppState *state) {
    int screen_width, screen_height;
    SDL_GetWindowSize(state->window, &screen_width, &screen_height);
    
    // 清屏背景色
    SDL_SetRenderDrawColor(renderer, 240, 240, 245, 255);
    SDL_RenderClear(renderer);

    // 1. 绘制标题栏
    SDL_SetRenderDrawColor(renderer, 30, 60, 120, 255);
    SDL_Rect title_rect = {0, 0, screen_width, 60};
    SDL_RenderFillRect(renderer, &title_rect);
    
    int text_width, text_height;
    TTF_SizeUTF8(font_large, "阻抗分析仪", &text_width, &text_height);
    render_text(font_large, "阻抗分析仪", 
               (screen_width - text_width)/2, 
               (60 - text_height)/2, 
               WHITE);

    // 2. 绘制主图表
    draw_graph(state);

    // 3. 绘制控制面板
    int panel_width = screen_width / 4;
    int panel_x = screen_width - panel_width;
    
    SDL_SetRenderDrawColor(renderer, 230, 235, 240, 255);
    SDL_Rect panel_rect = {panel_x, 60, panel_width, screen_height - 60};
    SDL_RenderFillRect(renderer, &panel_rect);
    SDL_SetRenderDrawColor(renderer, 180, 180, 180, 255);
    SDL_RenderDrawLine(renderer, panel_x, 60, panel_x, screen_height);

    // 4. 绘制设置项列表 - 优化顶部间距（上移10像素）
    int settings_top = 70; // 上移10像素
    draw_settings_list(state, panel_x, panel_width, settings_top);

    // 5. 根据模式绘制对应界面
    int settings_bottom = settings_top + SETTING_ITEMS * 70;
    int settings_y = settings_bottom + 15; // 增加间距
    
    switch(state->mode) {
        case FREQ_SETTING_MODE:
            draw_frequency_settings(state, panel_x, panel_width, settings_y);
            break;
        case COORD_SETTING_MODE:
            draw_coord_settings(state, panel_x, panel_width, settings_y);
            break;
        case TEST_MODE_SELECTION:
            draw_test_mode_selection(state, panel_x, panel_width, settings_y);
            break;
        case VIEW_MODE:
            draw_reference_point(state, panel_x, panel_width, settings_y);
            break;
        case MAIN_MODE:
            break;
        case MEASURING_MODE:
            break;
        default:
            break;
    }

    // 6. 更新显示
    SDL_RenderPresent(renderer);
}

void enhanced_median_filter(double* data, int size, int window_size) {
    if (window_size <= 1 || size <= 0) return;
    
    // 创建临时缓冲区（避免原地修改）
    double* temp = malloc(size * sizeof(double));
    if (!temp) return;
    
    int half = window_size / 2;
    
    for (int i = 0; i < size; i++) {
        // 计算实际窗口边界
        int start = i - half;
        int end = i + half;
        
        // 处理边界情况（镜像填充）
        if (start < 0) start = 0;
        if (end >= size) end = size - 1;
        
        // 提取窗口内数据
        int win_count = end - start + 1;
        double* window = malloc(win_count * sizeof(double));
        
        // 复制数据
        for (int j = 0; j < win_count; j++) {
            window[j] = data[start + j];
        }
        
        // 排序数组
        qsort(window, win_count, sizeof(double), compare_double);
        
        // 计算去掉最大值后的平均值
        double sum = 0.0;
        for (int j = 0; j < win_count - 1; j++) { // 跳过最后一个元素(最大值)
            sum += window[j];
        }
        temp[i] = sum / (win_count - 1); // 计算平均值
        
        free(window);
    }
    
    // 复制回原数组
    memcpy(data, temp, size * sizeof(double));
    free(temp);
}