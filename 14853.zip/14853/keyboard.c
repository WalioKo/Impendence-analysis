#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "keyboard.h"

#define DEBOUNCE_DELAY_MS 5   // 消抖延时（单位：毫秒）
#define SCAN_DELAY_US     100 // 扫描间隔（单位：微秒）

static struct gpiod_chip *chip = NULL;
static struct gpiod_line *row_lines[NUM_ROWS];
static struct gpiod_line *col_lines[NUM_COLS];

// 初始化 GPIO
KeyBoard_Error key_board_init(void) {
    const int row_pins[NUM_ROWS] = ROW_PINS;
    const int col_pins[NUM_COLS] = COL_PINS;
    
    // 打开GPIO芯片
    chip = gpiod_chip_open("/dev/gpiochip0");
    if (!chip) {
        perror("Failed to open GPIO chip");
        return KEY_BOARD_INIT_FAILED;
    }

    // 获取行GPIO线 (输入)
    for (int i = 0; i < NUM_ROWS; i++) {
        row_lines[i] = gpiod_chip_get_line(chip, row_pins[i]);
        if (!row_lines[i]) {
            perror("Failed to get row line");
            key_board_close();
            return KEY_BOARD_INIT_FAILED;
        }
        
        if (gpiod_line_request_input(row_lines[i], "matrix-keyboard") < 0) {
            perror("Failed to request row line as input");
            key_board_close();
            return KEY_BOARD_INIT_FAILED;
        }
    }

    // 获取列GPIO线 (输出)
    for (int i = 0; i < NUM_COLS; i++) {
        col_lines[i] = gpiod_chip_get_line(chip, col_pins[i]);
        if (!col_lines[i]) {
            perror("Failed to get col line");
            key_board_close();
            return KEY_BOARD_INIT_FAILED;
        }
        
        if (gpiod_line_request_output(col_lines[i], "matrix-keyboard", 1) < 0) {
            perror("Failed to request col line as output");
            key_board_close();
            return KEY_BOARD_INIT_FAILED;
        }
    }

    return KEY_BOARD_OK;
}

// 消抖函数
static int debounce_gpio_value(struct gpiod_line *line) {
    int value1, value2;

    value1 = gpiod_line_get_value(line);
    if (value1 < 0) {
        return -1;
    }

    usleep(DEBOUNCE_DELAY_MS * 1000);
    
    value2 = gpiod_line_get_value(line);
    if (value2 < 0) {
        return -1;
    }

    return (value1 == value2) ? value1 : -1;
}

// 扫描矩阵键盘，返回按下的按键字符
char key_board_scan(void) {
    int row, col;
    
    for (col = 0; col < NUM_COLS; col++) {
        // 设置当前列为低电平，其它列为高电平
        for (int i = 0; i < NUM_COLS; i++) {
            gpiod_line_set_value(col_lines[i], (i == col) ? 0 : 1);
        }

        usleep(SCAN_DELAY_US); // 等待电平稳定
        
        // 检查每一行
        for (row = 0; row < NUM_ROWS; row++) {
            int value = debounce_gpio_value(row_lines[row]);
            if (value == 0) { // 按键按下
                // 等待按键释放
                while (debounce_gpio_value(row_lines[row]) == 0) {
                    usleep(SCAN_DELAY_US);
                }
                return KEY_MAP[row][col];
            }
        }
    }
    
    return '\0'; // 没有按键按下
}

// 释放资源
void key_board_close(void) {
    // 释放行线资源
    for (int i = 0; i < NUM_ROWS; i++) {
        if (row_lines[i]) {
            gpiod_line_release(row_lines[i]);
            row_lines[i] = NULL;
        }
    }

    // 释放列线资源
    for (int i = 0; i < NUM_COLS; i++) {
        if (col_lines[i]) {
            gpiod_line_release(col_lines[i]);
            col_lines[i] = NULL;
        }
    }

    // 关闭GPIO芯片
    if (chip) {
        gpiod_chip_close(chip);
        chip = NULL;
    }
}