// menu.h - 阻抗分析仪菜单系统头文件
#ifndef MENU_H
#define MENU_H

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <stdbool.h>

// 定义常量
#define SCREEN_WIDTH 1024
#define SCREEN_HEIGHT 700
#define GRAPH_WIDTH 700
#define GRAPH_HEIGHT 500  // 增加图表高度
#define LEFT_MARGIN 30
#define TOP_MARGIN 20
#define FONT_SIZE 16

#define MENU_ITEMS 4       // 主菜单项数量
#define DATA_POINTS 200    // 数据点数(用于存储测量数据)
#define FREQ_STEPS 7       // 频率预设值数量
#define SETTING_ITEMS 3    // 设置项数量

// 测量模式枚举 - 定义阻抗分析仪支持的不同测量模式
typedef enum {
    IMPEDANCE_MODE,    // 阻抗模式 - 测量电路阻抗特性
    CAPACITANCE_MODE,  // 电容模式 - 测量电容值
    INDUCTANCE_MODE,   // 电感模式 - 测量电感值
    MAGNITUDE_MODE,    // 幅频模式 - 测量幅频特性
    PHASE_MODE         // 相频模式 - 测量相位特性
} MeasurementMode;

// 坐标系类型枚举 - 定义数据显示的坐标类型
typedef enum {
    LINEAR,       // 线性坐标 - 数据均匀分布
    LOGARITHMIC   // 对数坐标 - 数据按对数分布(适用于频率显示)
} CoordType;

// 应用模式枚举 - 定义应用程序的不同界面状态
typedef enum {
    MAIN_MODE,            // 主界面模式 - 显示主菜单和图表
    FREQ_SETTING_MODE,    // 频率设置模式 - 设置起始和终止频率
    COORD_SETTING_MODE,   // 坐标系设置模式 - 选择线性或对数坐标
    TEST_MODE_SELECTION,  // 测试模式选择 - 选择测量模式
    VIEW_MODE,            // 观察模式 - 查看详细数据点
    MEASURING_MODE        // 测量模式 - 正在进行测量
} AppMode;

// 频率设置类型枚举 - 定义当前正在设置的频率类型
typedef enum {
    START_FREQ,  // 起始频率 - 设置扫描的起始频率
    END_FREQ     // 终止频率 - 设置扫描的终止频率
} FreqSettingType;

// 设置项类型枚举 - 定义主界面中的可设置项目
typedef enum {
    FREQUENCY_SETTING,   // 频率设置项
    COORDINATE_SETTING,  // 坐标系设置项
    TEST_MODE_SETTING    // 测试模式设置项
} SettingType;

typedef enum {
    FILTER_NONE,    // 无滤波
    FILTER_MEDIAN,  // 中值滤波
    FILTER_AVG      // 移动平均
} FilterType;

// 应用状态结构体 - 保存应用程序的当前状态和设置
typedef struct {
    AppMode mode;                   // 当前应用模式
    MeasurementMode measurement_mode; // 当前测量模式
    CoordType coord;                // 当前坐标系类型
    FreqSettingType freq_setting;   // 当前设置的频率类型
    int selected_menu;              // 选中的菜单项索引
    int selected_test_mode;         // 选中的测试模式索引
    int selected_setting;           // 选中的设置项索引
    double start_freq;              // 起始频率值(Hz)
    double end_freq;                // 终止频率值(Hz)
    FilterType filter_type;
    int filter_window;
    float zoom_factor;              // 缩放因子(用于图表缩放)
    int cursor_x;                   // 光标X坐标(像素)
    int cursor_y;                   // 光标Y坐标(像素)
    double data[DATA_POINTS];       // 测量数据数组
    bool quit;                      // 退出标志 - 为true时退出程序
    bool measuring;                 // 测量中标志 - 为true时正在测量
    SDL_Window* window;             // SDL窗口指针

} AppState;

// 声明外部变量
extern const double freq_steps[FREQ_STEPS];  // 频率预设值数组
extern const char* setting_names[SETTING_ITEMS]; // 设置项名称数组

// 函数声明
// 初始化菜单系统 - 设置渲染器和字体
void init_menu_system(SDL_Renderer* renderer, TTF_Font* small_font, 
                     TTF_Font* medium_font, TTF_Font* large_font);
// 绘制主用户界面 - 根据当前状态绘制整个界面
void draw_main_ui(AppState *state);

void enhanced_median_filter(double* data, int size, int window_size);

#endif