#include "ad9834.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> 


struct gpiod_line *fsync_line;
struct gpiod_line *sclk_line;
struct gpiod_line *sdata_line;
struct gpiod_line *reset_line;
struct gpiod_line *fs_line;
struct gpiod_line *ps_line;

/* GPIO初始化 */
int init_gpio() {
    struct gpiod_chip *chip;
    
    chip = gpiod_chip_open_by_name(FSYNC_GPIO_CHIP);
    if (!chip) {
        perror("Open GPIO chip failed");
        return -1;
    }

    fsync_line = gpiod_chip_get_line(chip, FSYNC_GPIO_LINE);
    sclk_line = gpiod_chip_get_line(chip, SCLK_GPIO_LINE);
    sdata_line = gpiod_chip_get_line(chip, SDATA_GPIO_LINE);
    reset_line = gpiod_chip_get_line(chip, RESET_GPIO_LINE);
    fs_line = gpiod_chip_get_line(chip, FS_GPIO_LINE);
    ps_line = gpiod_chip_get_line(chip, PS_GPIO_LINE);

    if (!fsync_line || !sclk_line || !sdata_line || !reset_line || !fs_line || !ps_line) {
        perror("Get GPIO line failed");
        return -1;
    }

    if (gpiod_line_request_output(fsync_line, "ad9834", 1) < 0 ||
        gpiod_line_request_output(sclk_line, "ad9834", 1) < 0 ||
        gpiod_line_request_output(sdata_line, "ad9834", 1) < 0 ||
        gpiod_line_request_output(reset_line, "ad9834", 0) < 0 ||
        gpiod_line_request_output(fs_line, "ad9834", 0) < 0 ||
        gpiod_line_request_output(ps_line, "ad9834", 0) < 0) {
        perror("Request GPIO failed");
        return -1;
    }

    return 0;
}

/* 微秒延时函数 */
void delay_us(unsigned int us) {
    usleep(us);
}

/* 向AD9834写入16位数据 */
void AD9834_Write_16Bits(unsigned int data) {
    unsigned char i;
    
    gpiod_line_set_value(sclk_line, 1);
    gpiod_line_set_value(fsync_line, 0);
    delay_us(1);

    for (i = 0; i < 16; i++) {
        gpiod_line_set_value(sdata_line, (data & 0x8000) ? 1 : 0);
        delay_us(1);
        gpiod_line_set_value(sclk_line, 0);
        delay_us(1);
        data <<= 1;
        gpiod_line_set_value(sclk_line, 1);
        delay_us(1);
    }

    gpiod_line_set_value(sdata_line, 1);
    gpiod_line_set_value(fsync_line, 1);
}

/* 波形选择函数 */
void AD9834_Select_Wave(unsigned int initdata) {
    gpiod_line_set_value(fsync_line, 1);
    gpiod_line_set_value(sclk_line, 1);

    // 复位操作
    gpiod_line_set_value(reset_line, 1);
    delay_us(10);
    gpiod_line_set_value(reset_line, 0);
    delay_us(10);

    AD9834_Write_16Bits(initdata);
}

/* 初始化AD9834 */
void AD9834_Init() {
    if (init_gpio() != 0) {
        fprintf(stderr, "GPIO初始化失败\n");
        exit(EXIT_FAILURE);
    }

    // 附加初始化配置
    AD9834_Write_16Bits(0x2100);
    AD9834_Write_16Bits(0x2038);
    AD9834_Write_16Bits(0xC000);
    AD9834_Write_16Bits(0x2100);
}

/* 设置频率 */
void AD9834_Set_Freq(unsigned char freq_number, unsigned long freq) {
    unsigned long FREQREG = (unsigned long)(268435456.0 / AD9834_SYSTEM_CLOCK * freq);
    unsigned int FREQREG_LSB = (unsigned int)FREQREG;
    unsigned int FREQREG_MSB = (unsigned int)(FREQREG >> 14);

    if (freq_number == FREQ_0) {
        FREQREG_LSB = (FREQREG_LSB & 0x3FFF) | 0x4000;
        FREQREG_MSB = (FREQREG_MSB & 0x3FFF) | 0x4000;
    } else {
        FREQREG_LSB = (FREQREG_LSB & 0x3FFF) | 0x8000;
        FREQREG_MSB = (FREQREG_MSB & 0x3FFF) | 0x8000;
    }

    AD9834_Write_16Bits(FREQREG_LSB);
    AD9834_Write_16Bits(FREQREG_MSB);
}

/* 清理GPIO资源 */
void cleanup_gpio() {
    gpiod_line_release(fsync_line);
    gpiod_line_release(sclk_line);
    gpiod_line_release(sdata_line);
    gpiod_line_release(reset_line);
    gpiod_line_release(fs_line);
    gpiod_line_release(ps_line);
}