#ifndef KEY_BOARD_H
#define KEY_BOARD_H

#include <gpiod.h>

// 定义行和列的 GPIO 引脚编号
#define ROW_PINS { 60, 1, 2 }    // 3行
#define COL_PINS { 3, 38, 37 } // 3列

// 直接定义行列数量
#define NUM_ROWS 3
#define NUM_COLS 3
#define NUM_KEYS (NUM_ROWS * NUM_COLS)

// 按键映射表
static const char KEY_MAP[NUM_ROWS][NUM_COLS] = {
    {'1', '2', '3'},
    {'4', '5', '6'},
    {'7', '8', '9'}
};

// 错误码定义
typedef enum {
    KEY_BOARD_OK = 0,
    KEY_BOARD_INIT_FAILED,
    KEY_BOARD_SCAN_FAILED,
    KEY_BOARD_NO_KEY_PRESSED
} KeyBoard_Error;

// 初始化矩阵键盘 GPIO
KeyBoard_Error key_board_init(void);

// 扫描矩阵键盘，返回按下的按键字符
char key_board_scan(void);

// 释放资源
void key_board_close(void);

#endif /* KEY_BOARD_H */