#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>
#include <gpiod.h>
#include <locale.h>
#include <unistd.h>
#include "ads1115.h"
#include "ad9834.h"
#include "menu.h"
#include "keyboard.h" 


// 如果M_PI未定义，则定义π值
#ifndef M_PI
#define M_PI 3.1416
#endif
#define MAX_RETRIES 10
/**
 * 初始化SDL和TTF库
 * @param window 指向窗口指针的指针
 * @param renderer 指向渲染器指针的指针
 * @return 初始化成功返回true，失败返回false
 */
bool init_sdl(SDL_Window** window, SDL_Renderer** renderer) {
    // 初始化SDL视频子系统
    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        printf("SDL初始化失败: %s\n", SDL_GetError());
        return false;
    }
    
    // 初始化SDL_ttf字体子系统
    if (TTF_Init() != 0) {
        printf("TTF初始化失败: %s\n", TTF_GetError());
        SDL_Quit();
        return false;
    }
    
    // 创建全屏窗口
    *window = SDL_CreateWindow("阻抗分析仪", 
                            SDL_WINDOWPOS_CENTERED, 
                            SDL_WINDOWPOS_CENTERED,
                            0, 0,
                            SDL_WINDOW_FULLSCREEN_DESKTOP);
    if (!*window) {
        printf("窗口创建失败: %s\n", SDL_GetError());
        TTF_Quit();
        SDL_Quit();
        return false;
    }
    
    // 创建硬件加速的渲染器
    *renderer = SDL_CreateRenderer(*window, -1, 
                                SDL_RENDERER_ACCELERATED | 
                                SDL_RENDERER_PRESENTVSYNC);
    if (!*renderer) {
        printf("渲染器创建失败: %s\n", SDL_GetError());
        SDL_DestroyWindow(*window);
        TTF_Quit();
        SDL_Quit();
        return false;
    }
    
    return true;
}

/**
 * 加载字体文件，支持中文显示
 * @param path 首选字体路径
 * @param size 字体大小
 * @return 加载成功的字体指针，失败返回NULL
 */
TTF_Font* load_font(const char* path, int size) {
    // 尝试多种常见中文字体路径
    const char* font_paths[] = {
        path,
        "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",  // Linux文泉驿
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc", // Linux Noto
        NULL
    };
    
    TTF_Font* font = NULL;
    // 尝试加载每种字体路径，直到成功为止
    for (int i = 0; font_paths[i] != NULL; i++) {
        font = TTF_OpenFont(font_paths[i], size);
        if (font) {
            printf("成功加载字体: %s\n", font_paths[i]);
            return font;
        }
    }
    
    // 如果所有字体都加载失败，使用系统默认字体
    printf("警告: 无法加载任何中文字体，将使用默认字体\n");
    return TTF_OpenFont(NULL, size);
}

struct gpiod_chip *chip = NULL;
struct gpiod_line *line40 = NULL, *line41 = NULL;

float get_R_ref(int mode) {
    // 参数校验
    if (mode < 0 || mode > 3) {
        fprintf(stderr, "Error: Invalid mode (must be 0~3)\n");
        return -1;
    }

    // 设置GPIO电平组合
    switch (mode) {
        case 0:
            gpiod_line_set_value(line40, 0);
            gpiod_line_set_value(line41, 0);
            return 10.0;    // 10Ω
        case 1:
            gpiod_line_set_value(line40, 0);
            gpiod_line_set_value(line41, 1);
            return 1000.0;   // 1kΩ
        case 2:
            gpiod_line_set_value(line40, 1);
            gpiod_line_set_value(line41, 0);
            return 100000.0;  // 100KΩ
        case 3:
            gpiod_line_set_value(line40, 1);
            gpiod_line_set_value(line41, 1);
            return 1000000.0; // 10MΩ
        default:
            return -1; // 理论上不会执行
    }
}

void Calcu_Im(float VPHS, float VMAG, float Ref_R, float *R, float *Ph, float *Z) {
    // 计算幅度比（线性值）
    float gain_dB = (VMAG - 0.9f) / 0.03f; // VMAG转dB: (V-900mV)/30mV/dB
    float magnitude_ratio = powf(10.0f, gain_dB / 20.0f); // dB转线性比例

    // 计算相位差（度）
    float phase_diff = (VPHS - 0.9f) / 0.01f - 90; // VPHS转相位差: (V-900mV)/10mV/度

    // 计算复阻抗Z = Ref_R * (Va/Vb)
    float phase_rad = phase_diff * M_PI / 180.0f; // 角度转弧度
    float Z_real = magnitude_ratio * Ref_R * cosf(phase_rad); // 实部（电阻分量）
    
    *Z = magnitude_ratio * Ref_R*1000;
    *Ph = phase_diff; // 相位角（度）
    *R = Z_real;      // 电阻分量

    printf("Z: %.3f Ω, R: %.3f Ω, Phase: %.1f°\n", *Z, *R, *Ph);
}

// 优化后的相位符号调整函数 - 使用多点计算斜率
void adjust_phase_sign(int index, float freq, float *Ph_val, float *phase_history, float *freq_history) {
    // 更新历史记录
    for (int i = 0; i < 4; i++) {
        if (i < 3) {
            phase_history[i] = phase_history[i+1];
            freq_history[i] = freq_history[i+1];
        } else {
            phase_history[i] = *Ph_val;
            freq_history[i] = freq;
        }
    }
    
    // 至少需要3个点才能计算斜率
    if (index < 2) return;
    
    // 计算加权斜率（最近的点权重更大）
    float total_slope = 0.0f;
    float total_weight = 0.0f;
    
    // 计算所有点对之间的斜率
    for (int i = 0; i < 4; i++) {
        for (int j = i+1; j < 4; j++) {
            float freq_delta = freq_history[j] - freq_history[i];
            float phase_delta = phase_history[j] - phase_history[i];
            
            // 避免除以零
            if (fabs(freq_delta) > 1e-6) {
                float slope = phase_delta / freq_delta;
                float weight = 1.0f / (1 + abs(j - i)); // 距离越近权重越大
                
                total_slope += slope * weight;
                total_weight += weight;
            }
        }
    }
    
    // 计算平均斜率
    if (total_weight > 0) {
        float avg_slope = total_slope / total_weight;
        
        // 根据平均斜率调整相位符号
        if (avg_slope < -0.001f) { // 斜率为负，相位超前（容性）
            *Ph_val = -fabs(*Ph_val);
        } else if (avg_slope > 0.001f) { // 斜率为正，相位滞后（感性）
            *Ph_val = fabs(*Ph_val);
        }
        // 斜率接近零时不调整
    }
}

void measure_test(AppState *state, ADS1115_Config config, int *current_R_mode) {
    // 初始化相位分析状态
    float phase_history[5] = {0}; // 存储最近5个点的相位值
    float freq_history[5] = {0};   // 存储最近5个点的频率值
    int history_index = 0;
    
    for (int i = 0; i < DATA_POINTS; i++) {
        double x = (double)i / (DATA_POINTS - 1);
        double freq;
        
        // 计算频率
        if (state->coord == LINEAR) {
            freq = state->start_freq + x * (state->end_freq - state->start_freq);
        } else {
            freq = state->start_freq * pow(10, x * log10(state->end_freq / state->start_freq));
        }
        
        // 设置频率并等待稳定
        AD9834_Set_Freq(FREQ_0, freq);
        usleep(10000); // 10ms稳定时间，确保信号稳定
        
        // 读取电压
        float VPHS = 0, VMAG = 0;
        int ret;
        
        // 读取相位电压（AIN0）
        ret = ADS1115_ReadVoltage(&config, ADS1115_AIN0_GND, &VPHS);
        if (ret != ADS1115_OK) {
            printf("错误：无法读取相位电压 (AIN0), 错误码: %d\n", ret);
            continue; // 跳过当前点
        }
        
        // 读取幅度电压（AIN1）
        ret = ADS1115_ReadVoltage(&config, ADS1115_AIN1_GND, &VMAG);
        if (ret != ADS1115_OK) {
            printf("错误：无法读取幅度电压 (AIN1), 错误码: %d\n", ret);
            continue; // 跳过当前点
        }
        
        // 根据VMAG动态调整参考电阻
        if (VMAG > 1.5f && *current_R_mode < 3) {
            // 电压过高，切换到更大的参考电阻
            (*current_R_mode)++;
            gpiod_line_set_value(line41, (*current_R_mode & 0x01) ? 1 : 0);
            gpiod_line_set_value(line40, (*current_R_mode & 0x02) ? 1 : 0);
            printf("切换到参考电阻模式: %d\n", *current_R_mode);
            usleep(50000); // 等待50ms让电路稳定
        } else if (VMAG < 0.03f && *current_R_mode > 0) {
            // 电压过低，切换到更小的参考电阻
            (*current_R_mode)--;
            gpiod_line_set_value(line41, (*current_R_mode & 0x01) ? 1 : 0);
            gpiod_line_set_value(line40, (*current_R_mode & 0x02) ? 1 : 0);
            printf("切换到参考电阻模式: %d\n", *current_R_mode);
            usleep(50000); // 等待50ms让电路稳定
        }
        
        // 获取当前参考电阻值
        float Ref_R = 0;
        switch (*current_R_mode) {
            case 0: Ref_R = 10.0; break;      // 10Ω
            case 1: Ref_R = 1000.0; break;    // 1kΩ
            case 2: Ref_R = 100000.0; break;  // 100kΩ
            case 3: Ref_R = 1000000.0; break; // 1MΩ
            default: Ref_R = 1000.0; break;
        }
        
        // 计算阻抗
        float R_val, Ph_val, Z_val;
        Calcu_Im(VPHS, VMAG, Ref_R, &R_val, &Ph_val, &Z_val);
        
        // 分析相位变化斜率并调整相位符号
        if (state->measurement_mode == PHASE_MODE) {
            // 更新历史记录
            phase_history[history_index] = Ph_val;
            freq_history[history_index] = freq;
            history_index = (history_index + 1) % 5;
            
            // 使用多点计算斜率
            adjust_phase_sign(i, freq, &Ph_val, phase_history, freq_history);
        }
        
        // 计算复阻抗分量（用于电容/电感计算）
        float phase_rad = Ph_val * M_PI / 180.0f; // 度转弧度
        float imag_part = Z_val * sinf(phase_rad); // 虚部（电抗分量）
        
        // 存储数据
        switch (state->measurement_mode) {
            case IMPEDANCE_MODE:
                state->data[i] = Z_val; // 阻抗模值
                break;
                
            case CAPACITANCE_MODE:
                // 电容计算（当虚部为负）
                if (imag_part < 0) {
                    state->data[i] = -1.0f / (2 * M_PI * freq * imag_part);
                } else {
                    state->data[i] = 0; // 非电容特性
                }
                break;
                
            case INDUCTANCE_MODE:
                // 电感计算（当虚部为正）
                if (imag_part > 0) {
                    state->data[i] = imag_part / (2 * M_PI * freq);
                } else {
                    state->data[i] = 0; // 非电感特性
                }
                break;
                
            case MAGNITUDE_MODE:
                state->data[i] = 20 * log10(VMAG); // 幅度(dB)
                break;
                
            case PHASE_MODE:
                state->data[i] = Ph_val; // 相位(度)
                break;
        }
        
        // 定期处理事件，防止卡死
        if (i % 10 == 0) {
            SDL_PumpEvents(); // 处理SDL事件
            printf("点 %d/%d: 频率=%.1fHz, VMAG=%.3fV, R_mode=%d, Z=%.1fΩ, Ph=%.1f°\n", 
                   i+1, DATA_POINTS, freq, VMAG, *current_R_mode, Z_val, Ph_val);
        }
    }
    
    // 测量完成后应用滤波（跳过异常值）
    enhanced_median_filter(state->data, DATA_POINTS, 3);
    
    // 处理异常值（将NaN替换为相邻点的平均值）
    for (int i = 0; i < DATA_POINTS; i++) {
        if (isnan(state->data[i])) {
            // 寻找前后有效点
            float prev_val = (i > 0) ? state->data[i-1] : 0;
            float next_val = (i < DATA_POINTS-1) ? state->data[i+1] : prev_val;
            
            // 使用前后点的平均值
            state->data[i] = (prev_val + next_val) / 2.0f;
        }
    }
}
void simulate_capacitance_data(AppState *state, ADS1115_Config config, int *current_R_mode) {
    const float min_capacitance = 1e-9f;   // 1nF
    const float max_capacitance = 1e-6f;  // 1μF
    const float esr = 0.1f;               // 等效串联电阻(Ω)
    const float leakage = 1e6f;           // 漏电阻抗(Ω)
    
    // 随机生成电容值（对数分布）
    float base_cap = max_capacitance;
    
    for (int i = 0; i < DATA_POINTS; i++) {
        double x = (double)i / (DATA_POINTS - 1);
        double freq;
        
        // 计算频率（线性或对数坐标）
        if (state->coord == LINEAR) {
            freq = state->start_freq + x * (state->end_freq - state->start_freq);
        } else {
            freq = state->start_freq * pow(10, x * log10(state->end_freq / state->start_freq));
        }
        
        // --- 关键修正：避免除以零和无效计算 ---
        if (freq < 1.0f) freq = 1.0f;  // 频率最低限制为1Hz
        
        // 计算容抗（虚部为负）
        float Xc = -1.0f / (2 * M_PI * freq * base_cap);
        
        // 复阻抗计算：Z = R_esr + 1/(1/R_leak + jωC)
        float denom = 1.0f + powf(2 * M_PI * freq * base_cap * leakage, 2);
        float real_part = esr + leakage / denom;
        float imag_part = Xc / (1.0f + 1.0f/powf(2 * M_PI * freq * base_cap * leakage, 2));
        

        // --- 处理非法值 ---
        if (isnan(real_part) || isinf(real_part)) real_part = esr;
        if (isnan(imag_part) || isinf(imag_part)) imag_part = Xc;
        
        // 根据测量模式存储数据
        switch (state->measurement_mode) {
            case IMPEDANCE_MODE: {
                float impedance = sqrtf(real_part*real_part + imag_part*imag_part);
                state->data[i] = isnan(impedance) ? 0 : impedance;
                break;
            }
            case CAPACITANCE_MODE: {
                float capacitance = -1.0f / (2 * M_PI * freq * imag_part);
                    printf("Freq: %.1fHz, Cap: %.2enF\n", freq, capacitance*1e9);  // 以nF为单位输出
    state->data[i] = isnan(capacitance) ? 0 : capacitance;
                state->data[i] = isnan(capacitance) ? 0 : capacitance;
                break;
            }
            case INDUCTANCE_MODE:
                state->data[i] = 0;  // 纯电容，电感值为0
                break;
            case MAGNITUDE_MODE: {
                float magnitude = 20 * log10(1.0f / sqrtf(real_part*real_part + imag_part*imag_part));
                state->data[i] = isnan(magnitude) ? 0 : magnitude;
                break;
            }
            case PHASE_MODE: {
                float phase = atan2f(imag_part, real_part) * 180.0f / M_PI;
                state->data[i] = isnan(phase) ? 0 : phase;
                break;
            }
        }
    }
    
    // 滤波处理
    //enhanced_median_filter(state->data, DATA_POINTS, 3);


/**
 * 处理输入事件
 * @param state 应用程序状态指针
 * @param window SDL窗口指针
 */
/*void handle_input(AppState *state, SDL_Window* window) {
    SDL_Event event;
    // 处理所有待处理的事件
    while (SDL_PollEvent(&event)) {
        if (event.type == SDL_QUIT) {
            state->quit = true;
            return;
        }
        
        // 处理键盘按下事件
        if (event.type == SDL_KEYDOWN) {
            switch(event.key.keysym.sym) {
                case SDLK_LEFT:  // 左箭头键
                    if (state->mode == MAIN_MODE) {
                        // 在主模式下切换菜单项
                        state->selected_menu = (state->selected_menu - 1 + MENU_ITEMS) % MENU_ITEMS;
                    } else if (state->mode == FREQ_SETTING_MODE) {
                        // 在频率设置模式下切换设置项(起始/终止频率)
                        state->freq_setting = (state->freq_setting == START_FREQ) ? END_FREQ : START_FREQ;
                    } else if (state->mode == VIEW_MODE) {
                        // 在观察模式下移动光标
                        state->cursor_x -= 8;
                        if (state->cursor_x < 80) state->cursor_x = 80;
                    }
                    break;
                    
                case SDLK_RIGHT:  // 右箭头键
                    if (state->mode == MAIN_MODE) {
                        // 在主模式下切换菜单项
                        state->selected_menu = (state->selected_menu + 1) % MENU_ITEMS;
                    } else if (state->mode == FREQ_SETTING_MODE) {
                        // 在频率设置模式下切换设置项(起始/终止频率)
                        state->freq_setting = (state->freq_setting == START_FREQ) ? END_FREQ : START_FREQ;
                    } else if (state->mode == VIEW_MODE) {
                        // 在观察模式下移动光标
                        state->cursor_x += 8;
                        int screen_width, screen_height;
                        SDL_GetWindowSize(window, &screen_width, &screen_height);
                        int graph_right = screen_width * 3 / 4;
                        if (state->cursor_x > graph_right) state->cursor_x = graph_right;
                    }
                    break;
                    
                case SDLK_UP:  // 上箭头键
                    if (state->mode == MAIN_MODE) {
                        // 在主模式下切换设置项
                        state->selected_setting = (state->selected_setting - 1 + SETTING_ITEMS) % SETTING_ITEMS;
                    } else if (state->mode == FREQ_SETTING_MODE) {
                        // 在频率设置模式下调整频率值
                        double *target = (state->freq_setting == START_FREQ) ? &state->start_freq : &state->end_freq;
                        for (int i = 0; i < FREQ_STEPS; i++) {
                            if (*target == freq_steps[i]) {
                                *target = freq_steps[(i + 1) % FREQ_STEPS];
                                break;
                            }
                        }
                    } else if (state->mode == COORD_SETTING_MODE) {
                        // 在坐标系设置模式下切换坐标系类型
                        state->coord = (state->coord == LINEAR) ? LOGARITHMIC : LINEAR;
                    } else if (state->mode == TEST_MODE_SELECTION) {
                        // 在测试模式选择界面切换测试模式
                        state->selected_test_mode = (state->selected_test_mode - 1 + 5) % 5;
                    } else if (state->mode == VIEW_MODE) {
                        // 在观察模式下移动光标
                        state->cursor_y -= 8;
                        if (state->cursor_y < 70) state->cursor_y = 70;
                    }
                    break;
                    
                case SDLK_DOWN:  // 下箭头键
                    if (state->mode == MAIN_MODE) {
                        // 在主模式下切换设置项
                        state->selected_setting = (state->selected_setting + 1) % SETTING_ITEMS;
                    } else if (state->mode == FREQ_SETTING_MODE) {
                        // 在频率设置模式下调整频率值
                        double *target = (state->freq_setting == START_FREQ) ? &state->start_freq : &state->end_freq;
                        for (int i = 0; i < FREQ_STEPS; i++) {
                            if (*target == freq_steps[i]) {
                                *target = freq_steps[(i - 1 + FREQ_STEPS) % FREQ_STEPS];
                                break;
                            }
                        }
                    } else if (state->mode == COORD_SETTING_MODE) {
                        // 在坐标系设置模式下切换坐标系类型
                        state->coord = (state->coord == LINEAR) ? LOGARITHMIC : LINEAR;
                    } else if (state->mode == TEST_MODE_SELECTION) {
                        // 在测试模式选择界面切换测试模式
                        state->selected_test_mode = (state->selected_test_mode + 1) % 5;
                    } else if (state->mode == VIEW_MODE) {
                        // 在观察模式下移动光标
                        state->cursor_y += 8;
                        int screen_height;
                        SDL_GetWindowSize(window, NULL, &screen_height);
                        int graph_bottom = screen_height - 50;
                        if (state->cursor_y > graph_bottom) state->cursor_y = graph_bottom;
                    }
                    break;
                    
                case SDLK_RETURN:  // 回车键
                    if (state->mode == MAIN_MODE) {
                        // 在主模式下进入选中的设置项
                        switch (state->selected_setting) {
                            case FREQUENCY_SETTING:
                                state->mode = FREQ_SETTING_MODE;
                                state->freq_setting = START_FREQ;
                                break;
                            case COORDINATE_SETTING:
                                state->mode = COORD_SETTING_MODE;
                                break;
                            case TEST_MODE_SETTING:
                                state->mode = TEST_MODE_SELECTION;
                                state->selected_test_mode = 0;
                                break;
                        }
                    } else if (state->mode == TEST_MODE_SELECTION) {
                        // 在测试模式选择界面确认选择
                        state->measurement_mode = state->selected_test_mode;
                        state->mode = MAIN_MODE;
                    }
                    break;
                    
                case SDLK_s:  // S键
                    if (state->mode == MAIN_MODE && !state->measuring) {
                        // 开始测量
                        state->measuring = true;
                        state->mode = MEASURING_MODE;
                        
                        // 初始化光标位置到图表中心
                        int screen_width, screen_height;
                        SDL_GetWindowSize(window, &screen_width, &screen_height);
                        int graph_width = screen_width * 3 / 4 - 80;
                        int graph_height = screen_height - 160;
                        int graph_x = 80;
                        int graph_y = screen_height - graph_height - 50;
                        
                        state->cursor_x = graph_x + graph_width / 2;
                        state->cursor_y = graph_y + graph_height / 2;
                    }
                    break;
                    
                case SDLK_ESCAPE:  // ESC键
                    if (state->mode != MAIN_MODE && state->mode != MEASURING_MODE) {
                        // 返回主界面
                        state->mode = MAIN_MODE;
                    } else if (state->mode == MEASURING_MODE) {
                        // 取消测量
                        state->measuring = false;
                        state->mode = MAIN_MODE;
                    } else {
                        // 退出程序
                        state->quit = true;
                    }
                    break;
            }
        }
    }
}
*/

void handle_input(AppState *state, SDL_Window* window) {
    SDL_Event event;
    // 仍然处理SDL事件（如退出事件）
    while (SDL_PollEvent(&event)) {
        if (event.type == SDL_QUIT) {
            state->quit = true;
            return;
        }
    }

    // 扫描矩阵键盘按键
    char key_char = key_board_scan();
    if (key_char == '\0') {
        return; // 没有按键按下
    }

    // 将字符按键映射为数字（1-9）
    int key = key_char - '0';
    if (key < 1 || key > 9) {
        return; // 忽略无效按键
    }

    // 处理检测到的按键
    switch (key) {
        case 2:  // 按键1 (原左键)
            if (state->mode == MAIN_MODE) {
                state->selected_menu = (state->selected_menu - 1 + MENU_ITEMS) % MENU_ITEMS;
            } else if (state->mode == FREQ_SETTING_MODE) {
                state->freq_setting = (state->freq_setting == START_FREQ) ? END_FREQ : START_FREQ;
            } else if (state->mode == VIEW_MODE) {
                state->cursor_x -= 8;
                if (state->cursor_x < 80) state->cursor_x = 80;
            }
            break;
            
        case 3:  // 按键2 (原右键)
            if (state->mode == MAIN_MODE) {
                state->selected_menu = (state->selected_menu + 1) % MENU_ITEMS;
            } else if (state->mode == FREQ_SETTING_MODE) {
                state->freq_setting = (state->freq_setting == START_FREQ) ? END_FREQ : START_FREQ;
            } else if (state->mode == VIEW_MODE) {
                state->cursor_x += 8;
                int screen_width, screen_height;
                SDL_GetWindowSize(window, &screen_width, &screen_height);
                int graph_right = screen_width * 3 / 4;
                if (state->cursor_x > graph_right) state->cursor_x = graph_right;
            }
            break;
            
        case 1:  // 按键3 (原上键)
            if (state->mode == MAIN_MODE) {
                state->selected_setting = (state->selected_setting - 1 + SETTING_ITEMS) % SETTING_ITEMS;
            } else if (state->mode == FREQ_SETTING_MODE) {
                double *target = (state->freq_setting == START_FREQ) ? &state->start_freq : &state->end_freq;
                for (int i = 0; i < FREQ_STEPS; i++) {
                    if (*target == freq_steps[i]) {
                        *target = freq_steps[(i + 1) % FREQ_STEPS];
                        break;
                    }
                }
            } else if (state->mode == COORD_SETTING_MODE) {
                state->coord = (state->coord == LINEAR) ? LOGARITHMIC : LINEAR;
            } else if (state->mode == TEST_MODE_SELECTION) {
                state->selected_test_mode = (state->selected_test_mode - 1 + 5) % 5;
            } else if (state->mode == VIEW_MODE) {
                state->cursor_y -= 8;
                if (state->cursor_y < 70) state->cursor_y = 70;
            }
            break;
            
        case 4:  // 按键4 (原下键)
            if (state->mode == MAIN_MODE) {
                state->selected_setting = (state->selected_setting + 1) % SETTING_ITEMS;
            } else if (state->mode == FREQ_SETTING_MODE) {
                double *target = (state->freq_setting == START_FREQ) ? &state->start_freq : &state->end_freq;
                for (int i = 0; i < FREQ_STEPS; i++) {
                    if (*target == freq_steps[i]) {
                        *target = freq_steps[(i - 1 + FREQ_STEPS) % FREQ_STEPS];
                        break;
                    }
                }
            } else if (state->mode == COORD_SETTING_MODE) {
                state->coord = (state->coord == LINEAR) ? LOGARITHMIC : LINEAR;
            } else if (state->mode == TEST_MODE_SELECTION) {
                state->selected_test_mode = (state->selected_test_mode + 1) % 5;
            } else if (state->mode == VIEW_MODE) {
                state->cursor_y += 8;
                int screen_height;
                SDL_GetWindowSize(window, NULL, &screen_height);
                int graph_bottom = screen_height - 50;
                if (state->cursor_y > graph_bottom) state->cursor_y = graph_bottom;
            }
            break;
            
        case 7:  // 按键5 (原回车键)
            if (state->mode == MAIN_MODE) {
                switch (state->selected_setting) {
                    case FREQUENCY_SETTING:
                        state->mode = FREQ_SETTING_MODE;
                        state->freq_setting = START_FREQ;
                        break;
                    case COORDINATE_SETTING:
                        state->mode = COORD_SETTING_MODE;
                        break;
                    case TEST_MODE_SETTING:
                        state->mode = TEST_MODE_SELECTION;
                        state->selected_test_mode = 0;
                        break;
                }
            } else if (state->mode == TEST_MODE_SELECTION) {
                state->measurement_mode = state->selected_test_mode;
                state->mode = MAIN_MODE;
            }
            break;
            
        case 9:  // 按键6 (原S键)
            if (state->mode == MAIN_MODE && !state->measuring) {
                state->measuring = true;
                state->mode = MEASURING_MODE;
                
                int screen_width, screen_height;
                SDL_GetWindowSize(window, &screen_width, &screen_height);
                int graph_width = screen_width * 3 / 4 - 80;
                int graph_height = screen_height - 160;
                int graph_x = 80;
                int graph_y = screen_height - graph_height - 50;
                
                state->cursor_x = graph_x + graph_width / 2;
                state->cursor_y = graph_y + graph_height / 2;
            }
            break;
            
        case 8:  // 按键7 (原ESC键)
            if (state->mode != MAIN_MODE && state->mode != MEASURING_MODE) {
                state->mode = MAIN_MODE;
            } else if (state->mode == MEASURING_MODE) {
                state->measuring = false;
                state->mode = MAIN_MODE;
            } else {
                //state->quit = true;
            }
            break;
            
        default:
            break; // 忽略未定义的按键 
    }
}
/**
 * 清理资源
 * @param window SDL窗口指针
 * @param renderer SDL渲染器指针
 * @param small_font 小字体指针
 * @param medium_font 中字体指针
 * @param large_font 大字体指针
 */
void cleanup(SDL_Window* window, SDL_Renderer* renderer, 
             TTF_Font* small_font, TTF_Font* medium_font, TTF_Font* large_font) {
    // 释放字体资源
    if (small_font) TTF_CloseFont(small_font);
    if (medium_font) TTF_CloseFont(medium_font);
    if (large_font) TTF_CloseFont(large_font);
    // 释放渲染器和窗口
    if (renderer) SDL_DestroyRenderer(renderer);
    if (window) SDL_DestroyWindow(window);
    // 退出SDL_ttf和SDL
    TTF_Quit();
    SDL_Quit();
}


int main() {
    setlocale(LC_ALL, "");
    setlocale(LC_CTYPE, "zh_CN.UTF-8");
    
    SDL_Window* window = NULL;
    SDL_Renderer* renderer = NULL;
    TTF_Font* font_small = NULL;
    TTF_Font* font_medium = NULL;
    TTF_Font* font_large = NULL;
    
    // 1. 先初始化所有GPIO资源
    chip = gpiod_chip_open_by_name("gpiochip0");
    if (!chip) {
        perror("无法打开GPIO芯片");
        return 1;
    }
    
    // 初始化AD9834控制引脚
    line40 = gpiod_chip_get_line(chip, 40);
    line41 = gpiod_chip_get_line(chip, 41);
    if (!line40 || !line41) {
        perror("获取GPIO引脚失败");
        gpiod_chip_close(chip);
        return 1;
    }
    
    // 配置GPIO为输出模式
    if (gpiod_line_request_output(line40, "impedance", 0) < 0 || 
        gpiod_line_request_output(line41, "impedance", 0) < 0) {
        perror("配置GPIO输出失败");
        gpiod_chip_close(chip);
        return 1;
    }
    
    // 2. 初始化ADS1115
    ADS1115_Config config = {
        .channel = ADS1115_AIN0_GND,
        .gain = ADS1115_PGA_2V048,
        .data_rate = ADS1115_DR_860SPS,
        .op_mode = ADS1115_MODE_SINGLE,
        .i2c_addr = ADS1115_DEFAULT_ADDR
    };
    
    // 测试ADS1115是否正常工作
    float test_voltage;
    printf("正在初始化ADS1115...\n");
    if (ADS1115_Open(&config, 1) != ADS1115_OK) {
        printf("ADS1115初始化失败\n");
        gpiod_chip_close(chip);
        return -1;
    }
    
    // 尝试读取测试电压
    if (ADS1115_ReadVoltage(&config, ADS1115_AIN0_GND, &test_voltage) != ADS1115_OK) {
        printf("无法从ADS1115读取电压\n");
        gpiod_chip_close(chip);
        return -1;
    }
    printf("ADS1115初始化成功，测试电压: %.4f V\n", test_voltage);
    
    // 3. 初始化AD9834
    printf("正在初始化AD9834...\n");
    AD9834_Init();
    AD9834_Select_Wave(Sine_Wave);
    
    // 4. 初始化键盘
    printf("正在初始化键盘...\n");
    key_board_init();
    
    // 初始化应用状态
    AppState state = {
        .mode = MAIN_MODE,
        .measurement_mode = IMPEDANCE_MODE,
        .coord = LINEAR,
        .freq_setting = START_FREQ,
        .selected_menu = 0,
        .selected_test_mode = 0,
        .selected_setting = 0,
        .start_freq = 100,
        .end_freq = 30000000,
        .filter_type = FILTER_MEDIAN,
        .filter_window = 5,
        .zoom_factor = 1.0,
        .cursor_x = 0,
        .cursor_y = 0,
        .quit = false,
        .measuring = false,
        .window = NULL
    };
    
    // 5. 初始化SDL和TTF
    printf("正在初始化SDL...\n");
    if (!init_sdl(&window, &renderer)) {
        gpiod_chip_close(chip);
        return 1;
    }
    
    state.window = window;
    
    // 加载字体
    printf("正在加载字体...\n");
    font_small = load_font("wqy-microhei.ttc", 16);
    font_medium = load_font("wqy-microhei.ttc", 24);
    font_large = load_font("wqy-microhei.ttc", 36);
    
    if (!font_small || !font_medium || !font_large) {
        printf("错误: 无法加载字体文件\n");
        cleanup(window, renderer, font_small, font_medium, font_large);
        gpiod_chip_close(chip);
        return 1;
    }
    
    // 初始化菜单系统
    printf("正在初始化菜单系统...\n");
    init_menu_system(renderer, font_small, font_medium, font_large);
    
    // 初始化光标位置
    int screen_width, screen_height;
    SDL_GetWindowSize(window, &screen_width, &screen_height);
    state.cursor_x = screen_width / 3;
    state.cursor_y = screen_height / 2;
    
    Uint32 measure_start_time = 0;
    int current_R_mode = 1; // 初始参考电阻模式 (1kΩ)
    
    // 设置初始参考电阻
    gpiod_line_set_value(line41, (current_R_mode & 0x01) ? 1 : 0);
    gpiod_line_set_value(line40, (current_R_mode & 0x02) ? 1 : 0);
    
    printf("所有初始化完成，进入主循环...\n");
    
    // 主循环
    while (!state.quit) {
        // 处理输入事件
        handle_input(&state, window);
        
        // 处理测量逻辑
        if (state.measuring) {
            Uint32 current_time = SDL_GetTicks();
            
            if (measure_start_time == 0) {
                // 开始测量，记录开始时间
                measure_start_time = current_time;
                printf("开始测量...\n");
            }
            
            // 执行测量
            measure_test(&state, config, &current_R_mode);
            
            // 测量完成
            state.measuring = false;
            state.mode = VIEW_MODE;
            measure_start_time = 0;
            printf("测量完成\n");
        }
        
        // 绘制主界面
        draw_main_ui(&state);
        SDL_Delay(16);  // 控制帧率约60FPS
    }
    
    // 清理资源并退出
    cleanup(window, renderer, font_small, font_medium, font_large);
    key_board_close();
    
    // 释放GPIO资源
    gpiod_line_release(line40);
    gpiod_line_release(line41);
    gpiod_chip_close(chip);
    
    printf("程序正常退出\n");
    return 0;
}